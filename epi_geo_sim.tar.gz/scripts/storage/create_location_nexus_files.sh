#!/bin/bash


NEWICK_TREE_LIST=$1
NUM_LOCATIONS=$2
OUTPUT_PREFIX=$3

count=0
while read line;do
        ntax=$(tail -n +2 ${OUTPUT_PREFIX}_metadata*${count}.tsv|wc -l)
        echo '#NEXUS'$'\n'$'\n''Begin DATA;'$'\n'$'\t''Dimensions NTAX='${ntax} 'NCHAR=1;'$'\n'$'\t''Format MISSING=? GAP=- DATATYPE=STANDARD SYMBOLS="'$(echo $(seq 0 $(($NUM_LOCATIONS - 1))))'";'$'\n'$'\t''Matrix'$'\n' > ${OUTPUT_PREFIX}_sim${count}.location_tree.nexus

        tail -n +2 ${OUTPUT_PREFIX}_metadata_*${count}.tsv |cut -f 1,3 >> ${OUTPUT_PREFIX}_sim${count}.location_tree.nexus

        echo $'\t'';'$'\n'$'\n''END;' >> ${OUTPUT_PREFIX}_sim${count}.location_tree.nexus

        echo Begin trees\;$'\n' >> ${OUTPUT_PREFIX}_sim${count}.location_tree.nexus
        echo tree TREE_$count \= ${line} >> ${OUTPUT_PREFIX}_sim${count}.location_tree.nexus
        echo $'\n''END;' >> ${OUTPUT_PREFIX}_sim${count}.location_tree.nexus

        count=$((count+1))
done < $NEWICK_TREE_LIST

