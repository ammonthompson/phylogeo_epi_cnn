#!/bin/bash

nexus_trees_file=$1
out_file=$2
counter=0
while read tt;do 

	#tree_num=$(echo $tt |grep -Eo 'TREE_'[0-9]+)
	echo species$'\t'type$'\t'location$'\t'rxn$'\t'time > ${out_file}_metadata_sim${counter}.tsv
	echo $tt | grep -Eo '[0-9]+\[[^]]+\]' |sed -r 's/[a-z]+=//g' |\
	sed 's/"//g'|sed 's/,/\t/g'|sed 's/\[&/\t/g'|sed 's/[]]//g' >> ${out_file}_metadata_sim${counter}.tsv 
	counter=$((counter+1))

done < <(grep TREE_ $nexus_trees_file)
