#!/usr/bin/env Rscript

# collapse singles using phytools
library(phytools)

args <- commandArgs(trailingOnly = T)

#tree <- read.newick(args[1])
tree <- read.nexus(args[1])


if( class(tree) == "multiPhylo"){

	tree <- lapply(tree, collapse.singles)
	class(tree) <- "multiPhylo"
}else{

	tree <- collapse.singles(tree)
}

write.tree(tree, file = args[2])
