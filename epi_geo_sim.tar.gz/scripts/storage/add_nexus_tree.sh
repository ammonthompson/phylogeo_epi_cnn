#!/bin/bash
nexus_file=$1
tree=$2

# if nexus tree do
cat $nexus_file $tree > $(echo $nexus_file | sed 's/.nexus/.tree.nexus/g')

# if newick tree do
cat $nexus_file echo 'Begin trees;'$'\n' $(cat $tree) $'\n' END\;$'\n' > $(echo $nexus_file | sed 's/.nexus/.tree.nexus/g')

