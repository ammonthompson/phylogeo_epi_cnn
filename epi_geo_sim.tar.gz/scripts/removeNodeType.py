#!/usr/bin/env python3

# getAnnotation()

# removeNode()

#### main function #####
# getClade()

	# if "(" getClade()

		# if "[" getAnnotation()

			# if "Anno" removeNode()


